import React from "react";
import UserDashboard from "../components/user/UserDashboard";

export default function UserHome() {
  return <UserDashboard />;
}