import React from "react";
import OwnerDashboard from "../components/owner/OwnerDashboard";

export default function OwnerHome() {
  return <OwnerDashboard />;
}