import React from "react";

export default function AdminDashboard() {
  return <div>Admin Dashboard</div>;
}