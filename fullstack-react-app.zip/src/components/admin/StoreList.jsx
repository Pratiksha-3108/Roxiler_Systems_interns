import React from "react";

export default function StoreList() {
  return <div>Store List (fetch from DB)</div>;
}