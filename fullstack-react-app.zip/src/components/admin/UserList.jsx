import React from "react";

export default function UserList() {
  return <div>User List (fetch from DB)</div>;
}