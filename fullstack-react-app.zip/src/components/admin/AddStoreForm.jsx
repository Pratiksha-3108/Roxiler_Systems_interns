import React from "react";

export default function AddStoreForm() {
  return <form>Add Store Form</form>;
}