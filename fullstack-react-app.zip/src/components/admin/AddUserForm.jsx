import React from "react";

export default function AddUserForm() {
  return <form>Add User Form</form>;
}