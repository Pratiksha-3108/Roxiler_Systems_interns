import React from "react";

export default function Sidebar() {
  return <aside className="sidebar">Sidebar</aside>;
}