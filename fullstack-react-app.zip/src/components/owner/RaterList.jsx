import React from "react";

export default function RaterList() {
  return <div>Rater List (fetch from DB)</div>;
}