import React from "react";

export default function OwnerDashboard() {
  return <div>Owner Dashboard</div>;
}