import React from "react";

export default function StoreCard() {
  return <div>Store Card</div>;
}