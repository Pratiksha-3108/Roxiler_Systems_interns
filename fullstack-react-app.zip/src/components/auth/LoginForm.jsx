import React from "react";

export default function LoginForm() {
  return <form className="form">Login Form</form>;
}