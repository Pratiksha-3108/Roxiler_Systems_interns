import React from "react";

export default function SignupForm() {
  return <form className="form">Signup Form</form>;
}