import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import AdminHome from "./pages/AdminHome";
import UserHome from "./pages/UserHome";
import OwnerHome from "./pages/OwnerHome";
import ProtectedRoute from "./components/common/ProtectedRoute";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/admin" element={<ProtectedRoute><AdminHome /></ProtectedRoute>} />
        <Route path="/user" element={<ProtectedRoute><UserHome /></ProtectedRoute>} />
        <Route path="/owner" element={<ProtectedRoute><OwnerHome /></ProtectedRoute>} />
      </Routes>
    </Router>
  );
}

export default App;